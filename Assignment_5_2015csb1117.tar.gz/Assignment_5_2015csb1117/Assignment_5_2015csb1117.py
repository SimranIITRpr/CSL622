import networkx as nx
import matplotlib.pyplot as plt


#############################--------------------------###################################
#				2015csb1117						 #	
#				Shubham Dham						 #	
#											 #			
#  OUTPUT										 #
#  --> Run the file									 #
#  --> First created graph will be shown						 #
#  --> Then the distance between pairs will be shown on the terminal.			 #					
#					 						 #	
#  First the graph is created using the 'subj.txt' file.			         #	
#  A weighted undirected graph is created where weight for an edge 			 #	
#  between two nodes is set as inverse of the number of common subjects			 #	
#  between them. This inverse is done because we need the longest path between 		 #	
#  every pair of nodes. Hence by taking inverse, the problem changes to shortest 	 #
#  distance which can be done easily.							 #
#											 #
#  Also to check whether the weights are being used correctly, distance between 	 #
#  node 13 and 6 can be checked by using both cases. When the weights are not used,	 #
#  the path taken is the shorter one of the two possible equal paths. But when weights	 #	
#  are used, path used the longer one. In our case it comes out to be shorter because 	 #
#  we have taken inverse.								 #
#											 #
#############################--------------------------####################################




# Reading text file
with open("subj.txt") as textFile:
    lines = [line.split() for line in textFile]


# --- Creating Graph -----#
G = nx.Graph()
# Nodes Added

# added to get remove 0b before binary of a number
get_bin = lambda x: format(x, 'b') 

for each in lines:
	G.add_node(int(each[0]))

for each1 in G.nodes():
	for each2 in G.nodes():
		if each1 != each2:
			common_and = int(''.join(lines[each1-1][1:]), base=2) & int(''.join(lines[each2-1][1:]), base=2)
			common_int = sum([int(i) for i in get_bin(common_and)])
			if common_int > 0:
				G.add_edge(each1,each2,weight = 1/float(common_int)) # Add adges with weight
pos=nx.spring_layout(G)
nx.draw_networkx_nodes(G,pos)
nx.draw_networkx_edges(G,pos)
#nx.draw_networkx_edge_labels(G,pos)
nx.draw_networkx_labels(G,pos)
#nx.draw(G)
plt.show()

# Find shortest path between each pair of nodes
print 'Shortest Paths'
print '###--------####'
for each1 in G.nodes():
	for each2 in G.nodes():
		if each1 != each2:
			print 'shortest path between node ',each1,' and ',each2, 'is '
			print nx.shortest_path(G,each1,each2)
				
		



