Dependency:
	1) networkx
	2) numpy
	3) matplotlib

How to run:
	python3 index.py

Tasks:
	1) First finds rank of each node through random walk with a teleport of 0.2
	2) Then finds pagerank of each through networkx library.
	3) Compares and plots a graph of the same.

Observation:
	Boths the graphs looks somewhat similar.

Input:
	Reads input from google.txt kept in the same folder