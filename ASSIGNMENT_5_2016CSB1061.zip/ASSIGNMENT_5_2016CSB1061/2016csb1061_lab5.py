import networkx as nx
import matplotlib.pyplot as plt

G=nx.Graph()

dic={}
l=[]

#here I am creating a dictionary with key and values= tupple of 12.
fp=open('subj.txt','r')
for line in  fp:
	n=0
	for word in line.split():
		if (n==0):
			x=int(word)
		else:
			l.append(int (word))
		n=n+1
	dic[x]=list(l)
	del l[:]

dk=	dic.keys()

for i in dk:
	G.add_node(i)

for i in dk :
	for j in dk :
		if i!=j :
			l1=dic[i]
			l2=dic[j]
			it=0
			for z in range(n-1):					#here i am giving weight to the edges. 	
				if l1[z]==1 and l2[z]==1:
					it+=1
					G.add_edge(i,j,weight=1.0/it)


def best_shortest_path(n1,n2):
	if nx.has_path(G,n1,n2) :
		print list(nx.dijkstra_path(G,n1,n2))	# this finds the path with has maximum weighted edges
	else:
		print "No path between the given two nodes"	
n1=input("Enter node 1 : ")
n2=input("Enter node 2 : ")

best_shortest_path(n1,n2)
nx.draw(G,with_labels=True)
plt.show()