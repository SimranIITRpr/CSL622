#DataSet used web-Stanford.txt
#Link: https://snap.stanford.edu/data/web-Stanford.html
#Description : 
#		Nodes represent pages from Stanford University (stanford.edu) and directed edges represent hyperlinks between them. 
#		The data was collected in 2002.
#
#		Total Number Of Nodes 				: 281903
#		Total Number Of Edges 				: 2312497
# 		Average clustering coefficient  	: 0.5976
#		Number of triangles					: 11329473
#		Diameter (longest shortest path) 	: 674


#Implementation Of PageRank:
#		Number of iteration(teleportations) done are 1000000
#		Probability Of teleportation is 0.2



import random as ra
import networkx as nx
import matplotlib.pyplot as plt
import sys
import pylab

#Function to Create a Random Network
#Takes an int n which represents the number of Nodes in the graph
def CreateRandomNetwork(n):
    G = nx.DiGraph()
    G.add_nodes_from([i for i in range(n)])
    for i in range(n):
        for j in range(n):
            ran = ra.random();
            if ran<0.5:
                if i!=j:
                    G.add_edge(i,j)
    return G




#Create a Directed Graph by taking the file Name as Input
def createNetwork(fileName):
    G = nx.read_edgelist(fileName,create_using=nx.DiGraph())
    return G


#Finds The page ranks of every Node in the Graph G 
# Arguments Taken :
# G - Graph
# noi - number of iteration(Teleportations)
# prob - probability of teleportation
# return a Dictionary which has
# (node as key ) : (number of times the node has been visited as value)
def pageRank(G,noi,prob):
    nodesList = list(G.nodes())
    pageRankList = {}
    for i in nodesList:
        pageRankList[i]=0.0
    for i in range(noi):
        randomFromNode = ra.choice(nodesList)
        while(ra.random() > prob):
        	nONode =  list(G.neighbors(randomFromNode))
        	if(len(nONode) == 0):
        		break
        	randomToNode = ra.choice(list(G.neighbors(randomFromNode)))
        	pageRankList[randomToNode]+=1
        	randomFromNode = randomToNode
    return pageRankList    

if(len(sys.argv)<2):
	exit("please mention the file which has edgelist of Graph ..!")

print "importing network from the file.."
G=createNetwork(sys.argv[1])
print "Done..! "
print "Finding pageRank by created function.."
pageRankCal = pageRank(G,1000000,0.2)
sortedDict1 = sorted(pageRankCal.iteritems(), key=lambda (k,v): (v,k) , reverse =True )
print sortedDict1[1]
print "Done..!"
print "Finding pageRank by inbuilt function.."
pageRankIB = nx.pagerank(G)
sortedDict2 = sorted(pageRankIB.iteritems(), key=lambda (k,v): (v,k) , reverse =True )
print "Done..!"


X = [i for i,j in sortedDict1]
Y = [i for i,j in sortedDict2]

print "Comparing the two..."
print "plotting top 100 rank vs Nodes "
plt.plot(X[:100], 'ro' , label = 'Created Function')
plt.plot(Y[:100], 'go' , label = 'Inbuilt Function')
pylab.legend(loc='upper left')
plt.xlabel("Rank")
plt.ylabel("Nodes")
plt.show()



     
