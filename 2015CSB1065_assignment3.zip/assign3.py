#! /usr/bin/python
"""
@author: Narotam Singh 2015CSB1065

The network dataset file (Wiki-Vote.txt) used is a Wikipedia vote network. The file can be found
 at https://snap.stanford.edu/data/wiki-Vote.html 
Webgraph datasets from snap website are not used because of their large number of nodes and edges 
due to which code takes a long time to run and makes OS run out of memory.
This network contains 7115 nodes and 103689 edges. I have fixed the number of iterations.
To make the code run faster set the number of iterations limit to a lower value or change to a smaller graph. 
The number of iterations should be sufficient so that the nodes are visited sufficient number 
of times for them to be properly ranked. Make sure that the network text file is in the same destination as the code.
"""
import networkx as nx
import math
import matplotlib.pyplot as plt
import random as rd
##################################################################
G = nx.read_adjlist('Wiki-Vote.txt',nodetype = int,create_using = nx.DiGraph())
##################################################################
no_of_iterations=math.ceil(100*G.order());  #fixed number of iterations
##################################################################
tele_prob=0.2           #teleportation probabilty
##################################################################


def generate():         #modelling the probability
    return rd.random() >= tele_prob
dictionary=dict((n,0) for n in G.nodes())
initial_node=rd.choice(list(G.nodes()))
current_node=initial_node
dictionary[current_node]=dictionary[current_node]+1


for i in range(0,no_of_iterations):
    toss=generate()
    if(len(list(G.neighbors(current_node)))==0): # if no neighbors then teleport
        current_node=rd.choice(list(G.nodes()))
    elif(toss==1):      # 80 percent of time move to adjacent node
        current_node=rd.choice(list(G.neighbors(current_node)))
    elif(toss==0):      #20 percent of the time teleport
        current_node=rd.choice(list(G.nodes()))
    dictionary[current_node]=dictionary[current_node]+1

"""
Increasing the number of iterations helps the answer to converge to the page rank alogorithm output.
This is easily visible on a small graph.
"""
ranking=dictionary  # ranking is the output of random walk
page_rank=nx.pagerank(G) #page_rank is the output by page rank algortihm
#These two can be sorted by their values to see and compare the rank of nodes.
#Below the graph is plotted to compare the two.
a=[10000*x for x in list(page_rank.values())]
plt.plot(list(ranking.values()),a)
plt.xlabel('Rank from random walk')
plt.ylabel('10000*Rank from pagerank')
plt.title('Comparison')