import networkx as nx 
import matplotlib.pyplot as plt

#reading the network from file
G=nx.read_edgelist("out.ucidata-zachary",create_using=nx.Graph(),nodetype=int)

#return the key which has max value in a dictionary
def maxDict(Dic):
    Dict = Dic
    key = Dict.keys()
    maxDic = key[0]
    for i in key:
    	if(Dic[i]>Dic[maxDic]):
    		maxDic = i
    return maxDic;

#compute the edge betweeness of a graph
#input  : Graph
#output : a dictionary 
#		  keys  : frozenset of two integers representing a edge
#		  values: edgeBetwee  
def betweenness(G):
	el =  list(G.edges())
	betweennes = {};
	for i in range(G.number_of_edges()):
		temp = frozenset(el[i])
		betweennes[temp]=0.0
	nodesList = list(G.nodes()) 
	for node1 in nodesList:
		for node2 in nodesList:
			shortestPathsBetweeni_j = list(nx.all_shortest_paths(G,node1,node2));
			totalShortestPaths = float(len(shortestPathsBetweeni_j))
			for i in shortestPathsBetweeni_j:
				for j in range(len(i) - 1):
					if i[j] != i[j+1]:
						temp = frozenset([i[j] , i[j+1]])
						betweennes[temp] += 1.0/totalShortestPaths;
	return betweennes

#find Communities by girvan-newman algorithms
def find_components(G):
	while(nx.is_connected(G)):
		maxEdgeBetweenness = maxDict(betweenness(G))
		G.remove_edge(list(maxEdgeBetweenness)[0],list(maxEdgeBetweenness)[1])
	print "The Communities in the Graph are:"
	communities =  list(nx.connected_components(G))
	print "Community one :"
	print communities[0]
	print "Community two :"
	print communities[1]
	print " plot shows Disconnected Components(Communities) when edges having high betweennes are removed..!"
	nx.draw(G,with_labels=True)
	G.add_edge(21,11)
	plt.show()


find_components(G)