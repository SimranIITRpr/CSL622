Name : Vineel Kumar Raj BE
EntryNo : 2016csb1062

To run the code:
python girvan_newman.py

