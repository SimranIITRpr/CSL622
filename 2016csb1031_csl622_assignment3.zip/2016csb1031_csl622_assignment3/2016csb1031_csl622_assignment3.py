import matplotlib.pyplot as plt
import networkx as nx
import random as rn
from collections import OrderedDict
from operator import itemgetter

count=0
'''G=nx.Graph()
nod=['Delhi','Bangalore','Hyderabad','Ahmedabad','Chennai','Kolkata','Surat','Pune','Jaipur']

for each in nod:
    G.add_node(each)

while G.number_of_edges() < 30:
    c1=rn.choice(nod)
    c2=rn.choice(nod)
    if c1!=c2 and G.has_edge(c1,c2)==0:
        G.add_edge(c1,c2)'''

# Creating the graph from a dataset
G=nx.read_edgelist('web-polblogs.txt')
wcount = {}
nod = []


# page rank algorithm using random walk
def page_rank(G):
    # creating a list of nodes
    for each in nx.nodes(G):
        nod.append(each)
    print(nx.info(G))
    #nod.sort()
    # each count of nodes initialized to 0
    for each in nod:
        wcount[each] = 0
    # selecting any node at random
    ran_node=rn.choice(nod)
    wcount[ran_node]=wcount[ran_node]+1
    neigh=[]
    # getting all the neighbours of that node
    for z in G.neighbors(ran_node):
        neigh.append(z)
    # implementing the random walk or teleport with a probability of 0.8 or 0.2
    k=0
    while(k<nx.number_of_nodes(G)*100):
        if len(neigh) == 0:
            x = rn.choice(nod)
	    wcount[x] += 1
        else:
            flip=rn.random()
            if flip<=0.2:
                # teleport
                x = rn.choice(nod)
		wcount[x] += 1
            else:
                # random walk
                x=rn.choice(neigh)
		wcount[x] += 1
		neigh=[]
        	for z in G.neighbors(x):
            		neigh.append(z)
	k += 1


#the list for count from random walk page rank
one=[]
#the list for count from in biult page rank algorithm
two=[]
page_rank(G)
print("--------------------------------------")
for k, v in sorted(wcount.items(), key=lambda x:x[1],reverse=True):
    #print(k,v/90000)
    one.append(v)
print(one)

print("--------------------------------------")
pr = nx.pagerank(G,alpha=0.2)
for k, v in sorted(pr.items(), key=lambda x:x[1],reverse=True):
    #print(k,v)
    two.append(v)
print(two)

plt.plot(one,two,linewidth=10)
plt.show()
