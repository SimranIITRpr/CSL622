"""
s.shiva
2014csb1037
"""
import networkx as nx
import random
X=nx.read_adjlist("google.txt",nodetype=int, create_using=nx.DiGraph())
pr = nx.pagerank(X, alpha=0.9)
par=list(sorted(pr, key=pr.__getitem__,reverse=True))
#here par is list of ranked nodes according to page rank
def sortSecond(val):
    return val[1] 
e=list(X.nodes)
e.sort()
f=[]
for j in range(len(e)):
 f.append([e[j],0])
#rannod function returns randomly selected neighbour of a if there are 
#no neighbours it returns random node
def rannod(a):
 b=list(X[a])
 if b:
  return b[random.randint(0,len(b)-1)]
 else:
  return random.choice(list(X.nodes))
d=random.choice(list(X.nodes))
#here 100000 is the no of iterations i have given based on no of nodes 
#we can increase the iterations for better results
for i in range(100000):
 f[d-1][1]+=1
 c=random.randint(1,100)
 if c<=20:
  d=random.choice(list(X.nodes))
 else:    
  d=rannod(d)
f.sort(key=sortSecond,reverse=True)
#v=[]
#for i in range(len(f)):
# v.append(f[i][0])
#file = open("vals.txt","w") 
#for i in range(len(par)):
#  u=i-v.index(par[i])
#  file.write('%d' % u+'\n' )
#file.close() 

#page rank nodes sorted
print(par)
#f is a list of rankings of nodes contains 
#in this format [node,number of times we visited]
print(f)