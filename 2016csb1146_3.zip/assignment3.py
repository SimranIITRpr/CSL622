########################################## Author::Shreyans SOni ###############################
##########################################   Date::  9/7/2018     ###############################
########################################## About::Script to Compare Teleportation and pagerank ###############################

'''
This Python Scripts Comapare the Teleportation and Pagerank algorithms output By Plotting the Values of Probabilities of Ranks
in X and Y axis
The data-set which I have taken is "Wiki-Vote.txt" which is downloaded from the SNAP-dataset database
Link of dataset	=	https://snap.stanford.edu/data/wiki-Vote.html
Details of Graph as Follows:
Type: Graph
Number of nodes: 7115
Number of edges: 100762
Average degree:  28.3238

NOTE:The datset is huge that's why it may take 15 sec to run the Script and generate Output
OUTPUT: Output is similar to y=x (not exactly same) although this similarity will vary for different graphs

Usage:
>> python assignment3.py
'''
#Importing essentials libraries
import networkx as nx
import random
import matplotlib.pyplot as plt

############################### Function to Generate Random Graph ###################################
'''
########### Random Graph Generation ####################
G=nx.DiGraph()
G.add_nodes_from([i for i in range(20)])
i=1
while(i<100):
	u=r.choice(G.nodes())
	v=r.choice(G.nodes())
	if (u!=v and G.has_edge(u,v)==False):
		G.add_edge(u,v)
	i=i+1



#print(G.edges())
#print(G.nodes())
#########################################################
'''
#########################################################
G=nx.read_edgelist("Wiki-Vote.txt",nodetype=int)		#reading graph
Counter=dict((el,0.0) for el in G.nodes())			#hold counter value for all the visited nodes in Teleportation

sorted_pagerank=[]						#sorted pagerank() output is stored here
for key, value in sorted(nx.pagerank(G).iteritems(), key=lambda (k,v): (v,k),reverse=True):	#Sorting the pagerank output
	tup=[key,value]
	sorted_pagerank.append(tup)

################################### Random Walk On Graph #######################################
def random_walk(G,Counter):
	'''this function just randomly choose neighbour nodes and walks if any sink encountered than teleports'''
	u=r.choice(G.nodes())
	Counter[u] += 1
	i=0
	while(i<1000):
		neigh=[m for m in G[u]]				#Neighbour nodes
		if(len(neigh)!=0):				#IF neighbour exist than Random_Walk
			u=r.choice(neigh)
			Counter[u] += 1
		else:						#ELSE Teleport
			u=r.choice(G.nodes())
			Counter[u] += 1
		i=i+1
	print(Counter)						#returns a dictinary containing counter value for all visited nodes
####################################################


###################### Teleportation And Random Walk On Graph with Probability 0.2 ###########################
def tel_or_rand(G,Counter):
	'''This function teleports and Random walks on the graph with Pr 0.2 and 0.8 respectivily'''
	u=random.choice(list(G.nodes()))			#Choosing Random node @ first
	Counter[u] += 1	
	i=0
	while(i<1000000):					#Iterating 100000 times
		neigh=[m for m in G[u]]				#Getting all neighbour nodes
		if(len(neigh)==0):				#IF sink than again teleport
			u=r.choice(list(G.nodes()))
			Counter[u] += 1
		else:						#else Random Walk on neighbour nodes
			coin=random.random()
			if(coin<=0.2):				#Choosing Teleport with 0.2 probability
 				u=random.choice(list(G.nodes()))
				Counter[u] += 1
			else:
				u=random.choice(neigh)
				Counter[u] += 1
	
				
		i=i+1
	for each in Counter:					#decreasing the Value of Counter so we can plot easily
		Counter[each] = Counter[each]/1000000
	sorted_counter=[]
	for key, value in sorted(Counter.iteritems(), key=lambda (k,v): (v,k),reverse=True):	#Sorting the Output based on counter
		tup=[key,value]
		sorted_counter.append(tup)
	return sorted_counter
######################################################



############################ Comparing Results From Pagerank and Teleportation ##################################
def compare_results(res1,res2):
	'''This Function takes 2 list and compare those values by Plotting a Graph between them'''
	Y1=[]
	Y2=[]
	for i in res1:
		Y1.append(i[1])
	for i in res2:
		Y2.append(i[1])
	plt.title("Comparision of Pagerank and Telepotation Algorithm Output")		#Labels and Title
	plt.xlabel("Pagerank")
	plt.ylabel("Teleportation")
	plt.plot(Y1,Y2,'b',linewidth=7.0)						#Plotting the graph for comparision
	plt.show()
###################################################



sorted_teleport=tel_or_rand(G,Counter)					#Storing result of Teleportain (0.2) in sorted_teleport
#rand_walk(G,Counter)
#tel_or_rand(G,Counter)
compare_results(sorted_pagerank,sorted_teleport)			#calling the function to compare the results
