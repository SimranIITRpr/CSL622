

####################### ---------------------------- ############################
#			      2015CSB1117					#				
#			     Shubham Dham				        #
#										#			
#  From the graph, we can see that the plot of random walk VS pagerank 		#
#  gives almost a straight line of y=x. There are some noises or variations 	#
#  which can be removed by increasing the number of iterations of the random	#
#  walk. Increasing the number of iterations converges the plot to y=x plot.	#
#  Also the values on x and y axis are not same because the pagerank is 	#
#  normalised and gives value between 0 and 1. Some scaling has been done but 	#
#  but not exact. On Proper scaling, both gives same behavoiur over all the 	#
#  nodes with almost similar values.						#
#										#
#										#
#				DATASET 					#
#		            Wikipedia vote network				#
#  The network contains all the Wikipedia voting data from the inception of	#
#  Wikipedia till January 2008. Nodes in the network represent wikipedia users 	#
#  and a directed edge from node i to node j represents that user i voted on 	#
#  user j.									#
# 			    Nodes    -     7115					#
#			    Edges    -     103689				#
#	Average clusteing coefficent -     0.1409				#
#			    Diameter -     7					#
#		Number of Triangles  -     608389				#
#										#
#	Link - https://snap.stanford.edu/data/wiki-Vote.html                    #
####################### ---------------------------- ############################

#! /usr/bin/python
import networkx as nx
import matplotlib.pyplot as plt
import random

def random_pgrank():

	# 2015CSB1117 - Shubham Dham

	G = nx.read_adjlist('Wiki-Vote.txt',nodetype = int,create_using = nx.DiGraph())
	
	num = 1
	diction = {}
	for each in G.nodes():
		diction[each] = 0	# initilise a dictionary which holds the number of times each node is visited
	start_node = random.choice(list(G.nodes()))	
	diction[start_node] += 1
	node = start_node		# randomnly select start node
	while(num < G.number_of_nodes()*100):
		if len(list(G.successors(node))) == 0:		# if no successor to a node, find new random node
			node = random.choice(list(G.nodes()))
		else:	
			if (random.random() > 0.2):	# go to successor with probability 0.8
				node = random.choice(list(G.successors(node)))
			else:						# teleport with probability 0.2, go to new random node
				node = random.choice(list(G.nodes()))
		diction[node] += 1
		num += 1
	pgrank = nx.pagerank(G)
	plt.plot(diction.values(), [i*2000 for i in pgrank.values()])	 # pagerank values scaled to some extent
	plt.xlabel('random walk')
	plt.ylabel('pagerank')
	plt.title('pagerank vs random walk')
	plt.show()

	
random_pgrank()
