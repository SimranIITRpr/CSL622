########################################## Author::Shreyans SOni ###############################
##########################################   Date::  9/20/2018     ###############################
########################################## About::Python Script to Find Best Possible Path between Nodes###############################

'''
This Python Scripts is a Implementation to find the Best Possible path between all the edges of the given graph.

Suppose node s wants to meet node v, It can go through either node t or node u. In such case where there are multiple options, choose the node where the bond strength is more. Here bond strength is more for node u when compared to t (i.e. No of subjects commonly chosen by s and u is more compared to that of s and t). So choose the path s to u, then from u, there is a direct edge and hence it is the best path.
So the overall best path from s to v is s to u and u to v.

Solution: I first weighted all the edges by visiting them one by one and if any two of them will have comman subjects
	  Than I added a reverse weight to the edge(e.g. curent_weight=1/(previous_weight+1)) we are following this type of 
	  approach because if we used any shortest path algo on this graph than we will have the best possible path as
	  asked in the assignment .IF followed the approch of positive weight(e.g. current_weight=(previous_weight+1))
	  than we would end up getting reversed results of what we have expected.
 
The data-set which I have taken is Graph creaed from the data collected during a Servey of CSL622 2018 batch for their subjects
>> subj.txt

Details of Graph as Follows:
Type: Graph
Number of nodes: 14
Number of edges: 51
Average degree:   7.2857


OUTPUT: Output is The All Best Possible paths of all nodes and corresponding Graph. 

Usage:
>> python Assignment_5_2016csb1146.py
'''
#Importing essentials libraries
import networkx as nx
import matplotlib.pyplot as plt
import pprint
import os.path
import sys
import traceback
 

################################### Function for bond_strength #######################################
def bond_strength(nodes,nodes_s,G):			#Parameters passed are nodes and dict of matrix row corresponding to G and G
	for i in range(1, len(nodes_s)):		#Iterating through over dict
		for j in range(i + 1, len(nodes_s)+1):
			for eachi,eachj in zip(nodes_s[i],nodes_s[j]):	#Iterating via zip to iterate simultaneously
					if eachi == eachj and eachj == '1' and eachi == '1' :	#if Comman subjetcs are found 
						if not G.has_edge(i, j):			#between people than adding the edge 
							G.add_edge(i, j, weight = 1)		#with the 1/(previous_weight + 1)
						else:
							weight = float(1 / float(G[i][j]['weight']))
							G.remove_edge(i, j)
							G.add_edge(i,j,weight = 1 / (weight + 1))


################################### Function for Opening the file and reading values #######################################
def openfile():
	try:						#try catch bloc to prevent further errors and handling the exceptions
		if(os.path.isfile("subj.txt")):		#if found the file than read it's data accordingly
			file = open("subj.txt", "r")
			nodes_s = [node.strip() for node in file.readlines()]	#stripping the string line of file for variables
			nodes_s = {int(node.split()[0]):node.split()[1:] for node in nodes_s}	#dict of matrix row of all 14 people
			#nodes = nodes_s.keys()							#with their subjects as value and key as 
			#print(nodes_s)								#people
			return nodes_s
		else:					#else handling the exception
			print("File Not exist")
			sys.exit(0)
	except KeyboardInterrupt:			#Keyboard Exception
		print "Shutdown requested...exiting"
		sys.exit(0)	
	except Exception:				#All other exceptions with traceback
		traceback.print_exc(file=sys.stdout)
		sys.exit(0)	

################################### Function for adding nodes and constructing graph #######################################	
def add_nodes(nodes,nodes_s):
	G = nx.Graph()
	G.add_nodes_from(nodes)
	bond_strength(nodes,nodes_s,G)		#this function is implementation of weighting the edges in reverse/negetive order
	return G				#Returning the graph

################################### Main function to initiate the Programm #######################################		
def main():		
	nodes_s = openfile()			#Opening file fuction which retuns matrix of data in terms of dict
	nodes=nodes_s.keys()
	G = add_nodes(nodes,nodes_s)		#creating graph and adding the edges to graph
	for eachi in G.nodes():			#Now iterating through each node pair (u,v)
		for eachj in G.nodes():		#and displaying the best posible path between them
			if eachi != eachj and nx.has_path(G, eachi, eachj):	#here dijkstra algo is used to find the path 
				max_overlap = nx.dijkstra_path(G, eachi, eachj)	#parameter is weigth of edge which is negetive weighted   
				print "Best_possible_path from " + str(eachi) + " to " + str(eachj) + " is " + "-->" + str(max_overlap) + "<--"
	nx.draw_circular(G,with_labels=True)	#drawing the graph
	plt.title("Graph of 14 people with 12 subjects") 
	plt.show()				#plotting the graph you may comment this if wanted


#####################################################****END OF FUNCTIONS*****############################################

main()						#initiating the main thread
