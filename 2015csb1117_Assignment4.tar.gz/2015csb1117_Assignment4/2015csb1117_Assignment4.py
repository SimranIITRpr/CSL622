import networkx as nx
from itertools import combinations
import operator
import matplotlib.pyplot as plt
 
################--------------------------######################
#		      2015csb1117                              #
#		      Shubham Dham			       #
#							       #	
# The program outputs the graph with the separated components. # 
# Also it outputs the two set of nodes of the two components.  #
# In order to check the betweenness value calculated by the    #
# code and in built function, passn 'normalized = 0' in the    #
# in built 'edge_betweenness_centrality' parameters.This is    #
# because the betweenness values calculated by the code are    #
# not normalized.					       #
#							       #
################-------------------------#######################

def func():

	G =  nx.read_adjlist('out.ucidata-zachary', nodetype= int)

	while (nx.is_connected(G)):
		
		between = {}			# dictionary to hold the betweenness values of egdes
		for (u,v) in G.edges():
			between[u,v] = 0

		for (u,v) in combinations(G.nodes(),2):    # for each pair of nodes, iterate
			all_path = list(nx.all_shortest_paths(G,u,v))     # all shortest paths between a pair of nodes
			total_paths = len(all_path)     		  # number of total shortest paths	
			for each_path in all_path:			
				for each in range(len(each_path)-1):	  # add to the betweenness value of each edge in the each path of 
									  # total shortest path between a pair of nodes
	
					#if (u == min(each_path[each],each_path[each+1]) and v == max(each_path[each],each_path[each+1])):	
					#	continue
					between[min(each_path[each],each_path[each+1]),max(each_path[each],each_path[each+1])] += 1/float(total_paths)

		(a,b) = max(between.iteritems(), key = operator.itemgetter(1))[0]		
		G.remove_edge(a,b)
		
	#while(nx.is_connected(G)):
	#	c = nx.edge_betweenness_centrality(G)
	#	(a,b) = max(c.iteritems(), key = operator.itemgetter(1))[0]		
	#	G.remove_edge(a,b)
		
	print list(nx.connected_components(G))	
	nx.draw(G)
	plt.show()							
func()	
