import networkx as nx
import matplotlib.pyplot as plt

d={}
G=nx.Graph()
#read the graph file
f=open('subj.txt','r')
#putting them in a dictionary
for line in f:
	count=0
	l=[]
	for word in line.split():
		if (count==0):
			key=int(word)
		else:
			l.append(int(word))
		count+=1
	d[key]=list(l)

nod=[]
nod=d.keys()
for i in nod:
	G.add_node(i)

#snippet to add weight to a graph
for i in nod:
	for j in nod:
		if i != j :
			listA=d[i]
			listB=d[j]
			w=0
			for k in range(count-1): 	
				if listA[k]==1 and listB[k]==1:
					w+=1
					G.add_edge(i,j,weight=1.0/w)

#best shortest path function
def bsp(x,y):
	print list(nx.dijkstra_path(G,x,y))	

if __name__=="__main__":
	nx.draw(G,with_labels=True)
	plt.show()
	print("Graph created.....Now best paths between each pair of nodes")
	for i in range(1,15):
		for j in range(i+1,15):
			bsp(i,j)
