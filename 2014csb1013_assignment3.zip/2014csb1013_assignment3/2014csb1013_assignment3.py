# this code is written By Gurkaranpreet Singh 2014csb1013
# source of this code is : http://networkrepository.com
# open this website scroll down Click on web Graph
# New Page will open having table which shows various web graphs
#select web-edu to download the web graph in .mtx format
# i converted .mtx to .txt format before using it
# i will upload my dataset along with code


import networkx as nx
import matplotlib.pyplot as pt
import random as rn

G= nx.read_edgelist('web-edu.txt', nodetype=int)
 # import dataset to form graph G
print(G.number_of_nodes())
#viewing number of nodes in graph
mydict={x:0 for x in range(1,3032)}
#creating dictionary in python of length n which number of nodes in graph 
#this dictionary containes nodes as key and value attacthed with key represents number of times we visit each node during iteration
r = rn.choice(list(G.nodes()))
# we are selecting random node out of our Graph to start random Walk
#here we start the loop for random walk
for i in range(100000):
   c=rn.random()
   #finding tele-probability
   if c<=0.2:
       #now we are randoming selecting nodes out of other nodes
       r=rn.choice(list(G.nodes()))
       #we are visitng the randomly chosen node
       mydict[r]=mydict[r]+1
       #hence incrementingthe value attached with node as key
   else:
       #here if c>0.2 we are selecting our next node in random walk as any one neighbor of node r
        A=list(G.neighbors(r))
        r=rn.choice(A)
        mydict[r]=mydict[r]+1
        #out of all the neighbors of r we are randomly selecting one of them
        # and visiting them

print(mydict)
# printing the result of our random walk in format node: number of time visited during random walk
p = nx.pagerank(G, alpha=0.9)
#finding pagerank by inbuit function in python
print(p)
#printing the pagerank in similar format as random walk


        
