'''

    Author : Rishabh Kumar
    Entry Number : 2014CSB1027

    Using networkx package

    Link to the Dataset : http://networkrepository.com/web-google.php

'''

import networkx as nx
import random

# load adjacency list in digraph
myGraph = nx.read_adjlist("graph.txt", nodetype=int, create_using=nx.DiGraph())
pageRankA = nx.pagerank(myGraph, alpha=0.9)
sortedPageRankList = list(sorted(pageRankA, key=pageRankA.__getitem__, reverse=True))


# Return the number of visits of a node
def getSecondIndexValue(val):
    return val[1]


# get list of nodes
nodesList = list(myGraph.nodes)

# sort all the nodes
nodesList.sort()

# create a empty list to store edges and their number of visits
nodeVisits = []

# Create list with initial node visits as 0
for j in range(len(nodesList)):
    nodeVisits.append([nodesList[j], 0])


# function for the random walk
def randomWalk(firstNode):
    # return all neighbours of a
    listNeighbours = list(myGraph[firstNode])

    # if neighbours are not null move to a random neighbour
    if listNeighbours:
        return random.choice(listNeighbours);
    # otherwise jump to a random node
    else:
        return random.choice(list(myGraph.nodes))


# select a random node
initialNode = random.choice(list(myGraph.nodes))


def getProbability():
    c = random.randint(1, 1000)
    if c <= 200:
        return 1;
    else:
        return 0;


# count number of visits on every node in 100000 iterations
for i in range(200000):
    # selected node count by 1
    nodeVisits[initialNode - 1][1] += 1
    if getProbability():
        initialNode = random.choice(list(myGraph.nodes))
    else:
        initialNode = randomWalk(initialNode)
nodeVisits.sort(key=getSecondIndexValue, reverse=True)

print(sortedPageRankList)
print(nodeVisits)
