import networkx as nx
import matplotlib.pyplot as plt


#list Of Nodes
nodesList = []

with open("subj.txt","r") as f:
    for line in f:
        nodesList+=[line.strip()[-23:].split(" ")]

#finds the number of common subjects between Two Nodes
def similarSubjects(node1,node2):
    numOfSubs = len(node1)
    count =0
    for i in range(numOfSubs):
        if(node1[i]==node2[i] and node1[i] == "1"):
            count+=1
    return count


#A Undirected Graph G
G = nx.Graph()
#Nodes are from [1,n]
G.add_nodes_from([i for i in range(1,len(nodesList)+1)])

#For every Two nodes in the graph
#if the Similar Subjects between two nodes is greater than 0
#add an edge with weight 1/numberOfSimilarSubjects

for i in range(len(nodesList)):
    for j in range(len(nodesList)):
        similarSubjectsCount = similarSubjects(nodesList[i],nodesList[j])
        if  similarSubjectsCount != 0 :
            similarSubjectsCountInv = 1.0/float(similarSubjectsCount)
            G.add_edge(i+1,j+1,weight = similarSubjectsCountInv) 



#Command Line interface To get user input
while(1):
    print "Enter 0 To exit."
    FromNode = input("Enter The From Node : ")
    if(FromNode == 0):
        break;
    if FromNode not in range(1,len(nodesList)+1):
        print "Enter Valid Node."
        continue; 
    ToNode = input("Enter The To Node : ")
    if(ToNode == 0):
        break;
    if ToNode not in range(1,len(nodesList)+1):
        print "Enter Valid Node"
        continue;
    print "Best Path between Nodes "+str(FromNode) +" - "+str(ToNode)+" : "+ str(nx.dijkstra_path(G,FromNode,ToNode));