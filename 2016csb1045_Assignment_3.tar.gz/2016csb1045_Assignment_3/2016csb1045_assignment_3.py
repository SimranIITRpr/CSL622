import networkx as nx
import matplotlib.pyplot as plt
import random as rn
number = 10
nodes_dict = {}

G = nx.read_edgelist('test.txt', nodetype=int, create_using= nx.DiGraph())

for i in list(G.nodes()):
	nodes_dict[i] = 0

def page_rank(root):
	nodes_dict[root] += 1
	neighbours = list(G.neighbors(root))
	if rn.random() < 0.2 or neighbours == []:
		return -1
	next_node = rn.choice(neighbours)
	if next_node != []:
		return next_node			


for i in range(len(G.nodes())*1000):
	root = rn.choice(list(G.nodes()))
	while root != -1:
		root = page_rank(root)

for i in nodes_dict:
	nodes_dict[i] = nodes_dict[i]/(len(nodes_dict)*1000)


print("MY ALGO TOP " + str(number) + " RESULTS")
count = 0
for i in reversed(sorted((v,k) for (k,v) in nodes_dict.items())):
	print (i[1])
	count = count + 1
	if count == number:
		break

nodes_dict = {}
nodes_dict = nx.pagerank(G)

print("===================")
print("INBUILT ALGO TOP " + str(number) + " RESULTS")
count = 0
for i in reversed(sorted((v,k) for (k,v) in nodes_dict.items())):
	print (i[1])
	count = count + 1
	if count == number:
		break
