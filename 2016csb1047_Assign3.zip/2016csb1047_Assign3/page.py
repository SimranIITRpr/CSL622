import networkx as nx
import matplotlib.pyplot as plt
import random as rn
import collections

no_iterations = 0
l = {}
ll = {}


#G = nx.read_edgelist('web-Google.txt', nodetype=int, create_using= nx.DiGraph())
G = nx.read_edgelist('test.txt', nodetype=int, create_using= nx.DiGraph())


'''
G = nx.DiGraph()

for i in range(100): 
	G.add_node(i)

for i in range(100):
	for j in range(100):
		if(i!=j and rn.random() < .1):
			G.add_edge(i, j)
'''

for i in list(G.nodes()):
	l[i] = 0


#nx.draw(G)
#plt.show()

def pagerank(start_node):
#	print(start_node)
	l[start_node] += 1
	global no_iterations
	no_iterations += 1
	neighbors = list(G.neighbors(start_node))
	if rn.random() <.2 or neighbors == []:
		return -1
	next_node = rn.choice(neighbors)
	if next_node != []:
		return next_node			


print("iterations = "+str(len(l)*1000))
for i in range(len(G.nodes())*1000):
	start_node = rn.choice(list(G.nodes()))
	while start_node != -1:
		start_node = pagerank(start_node)


for i in l:
	l[i] = l[i]/no_iterations

print("Showing Top 10 results")

print("-----------My Algo------------")
print("Probability			Node number")
max_result_size = 10
iter_n = 0

for i in reversed(sorted((v,k) for (k,v) in l.items())):
	print (str(i[0])+"		"+str(i[1]))
	iter_n +=1
	if iter_n == max_result_size:
		break


ll = nx.pagerank(G)

print("-----------Inbuilt Fun------------")
print("Probability			Node number")
iter_n = 0
for i in reversed(sorted((v,k) for (k,v) in ll.items())):
	print (str(i[0])+"		"+str(i[1]))
	iter_n +=1
	if iter_n == max_result_size:
		break
