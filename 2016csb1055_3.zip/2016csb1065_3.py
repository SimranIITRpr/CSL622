#dataset obtained from SNAP dataset web-polblogs.txt
#Author :: Yashwant Sihara 2016csb1065
import matplotlib.pyplot as plt
import networkx as nx
import random as rn

G = nx.read_edgelist("web-polblogs.txt",nodetype=int)
pr = nx.pagerank(G)
pr_sort=[]
pr_sorted = list(sorted(pr.items(), key = lambda x: x[1], reverse = True))
for each in pr_sorted:
	pr_sort.append(each[1])
di={}
nodes=G.nodes()
for k in nodes:
	di[k]=0.0
def tel(G):
    nodes = list(G.nodes())
    pick_node = rn.choice(nodes)
    di[pick_node] += 1
    i=0
    while(i<100000):
        nb=[el for el in G[pick_node]]
        if(len(nb)==0):
            pick_node=rn.choice(list(G.nodes))
            di[pick_node] += 1
        else:
            fl=rn.random()
            if(fl>=0.2):
                pick_node=rn.choice(nb)
                di[pick_node] += 1
            elif(fl<0.2):
                pick_node=rn.choice(list(G.nodes))
                di[pick_node] += 1
        i += 1
    return di

def com_list(l1,l2):
	plt.plot(l1,l2, '--r', linewidth = 5.0)
	plt.show()	
tel_list = tel(G)

sorted_rw=list(sorted(tel_list.values(),reverse=True))
com_list(pr_sort,sorted_rw)

