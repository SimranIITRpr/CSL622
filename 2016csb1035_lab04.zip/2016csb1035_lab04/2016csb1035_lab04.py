'''
assignment 4
2016csb1035
Jagadeesh Chavali
'''
import networkx as nx
import random as rand
import matplotlib.pyplot as plt
#read graph
G = nx.read_edgelist("karate.txt", nodetype = int)
N=list(G.nodes())
n=len(N)

E = G.edges()
# define betweenness list
betweenness={}
nop={}
for i in E:
    betweenness[i]=0
    nop[i]=0
#compute betweenness
for i in range(n):
    for j in range(i+1,n):
         P=nx.all_shortest_paths(G,N[i],N[j])#find all shortest paths through s,t
         P=list(P)
         p=len(P)
         for k in range(p-1):
             for l in range(len(P[k])-1):
                      a,b = min(P[k][l],P[k][l+1]),max(P[k][l],P[k][l+1])#no of shortest paths which contains edge
                      nop[(a, b)] += 1
                      nop[(a,b)] = nop[(a,b)]/p#divide with total no of shortest paths
                      betweenness[(a,b)] += nop[(a,b)]
                      nop[(a,b)]=0
                      
#reorder wrt the betweenness values
Q = []
for i,j in betweenness.iteritems():
        Q.append((j,i))
        Q = sorted(Q)	
#remove one by one with highest betweenness          
while(nx.is_connected(G)):
          s=Q.pop()
          G.remove_edge(s[1][0],s[1][1])
#remove the last edge to make it disconnected         
s=Q.pop()
G.remove_edges(s[1][0],s[1][1])
nx.draw(G,with_labels=1)
plt.show()		  		              